#算法模型 放倒当前目录下
模型列表
cws_dat.bin
cws_label.txt
cws_model.bin
idiom.dat
model_c_dat.bin
model_c_label.txt
model_c_model.bin
model_w
neg.dat
ns.dat
singlepun.dat
t2s.dat
time.dat
vD.dat
vM.dat
xu.dat